<?php
/**
 * Plugin Name: Creator Shopy - Page Publisher
 * Description: Recibe y sirve páginas estáticas HTML creadas desde el Constructor de Creator Shopy.
 * Version: 1.0.0
 * Author: Antigravity
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Configuración de la clave secreta compartida
define( 'CREATOR_SHOPY_API_KEY', 'Ca$79652475' );

// Registrar endpoint de la API REST
add_action( 'rest_api_init', function () {
    register_rest_route( 'creator-shopy/v1', '/publish', array(
        'methods'             => 'POST',
        'callback'            => 'creator_shopy_publish_page',
        'permission_callback' => 'creator_shopy_publish_permissions',
    ) );
} );

// Validar token de autorización
function creator_shopy_publish_permissions( $request ) {
    $auth_header = $request->get_header( 'Authorization' );
    if ( ! $auth_header ) {
        return false;
    }
    
    $token = str_replace( 'Bearer ', '', $auth_header );
    return ( $token === CREATOR_SHOPY_API_KEY );
}

// Guardar la página en la base de datos
function creator_shopy_publish_page( $request ) {
    $params = $request->get_json_params();
    $slug   = sanitize_title( $params['slug'] );
    $html   = $params['html'];
    
    if ( empty( $slug ) || empty( $html ) ) {
        return new WP_Error( 'invalid_data', 'Slug and HTML content are required.', array( 'status' => 400 ) );
    }
    
    // Guardar en las opciones de WordPress usando un prefijo
    update_option( 'creator_shopy_landing_' . $slug, $html );
    
    // Guardar el slug en la lista de páginas activas
    $active_landings = get_option( 'creator_shopy_active_landings', array() );
    if ( ! in_array( $slug, $active_landings ) ) {
        $active_landings[] = $slug;
        update_option( 'creator_shopy_active_landings', $active_landings );
    }
    
    return array( 'success' => true, 'slug' => $slug );
}

// Interceptar ruta y servir el HTML estático si coincide
add_action( 'template_redirect', function() {
    $request_uri = parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );
    $current_slug = trim( $request_uri, '/' );
    
    if ( empty( $current_slug ) ) {
        return;
    }
    
    $active_landings = get_option( 'creator_shopy_active_landings', array() );
    if ( in_array( $current_slug, $active_landings ) ) {
        $html = get_option( 'creator_shopy_landing_' . $current_slug );
        if ( ! empty( $html ) ) {
            status_header( 200 );
            header( 'Content-Type: text/html; charset=UTF-8' );
            echo $html;
            exit;
        }
    }
} );
